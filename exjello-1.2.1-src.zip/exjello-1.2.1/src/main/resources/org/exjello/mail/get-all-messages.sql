SELECT
    "urn:schemas:httpmail:fromemail"
FROM "" WHERE
    "DAV:iscollection" = False AND
    "DAV:ishidden" = False
ORDER BY "DAV:creationdate"
